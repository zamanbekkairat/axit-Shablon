    $(document).ready(function(){
        $(".s-button__remove1").click(function(){
          $(".sec3").css("display", "block");
          $(".sec4").css("display", "none");
          $(".sec5").css("display", "none");
        });
      });

      $(document).ready(function(){
        $(".s-button__remove2").click(function(){
          $(".sec3").css("display", "none");
          $(".sec4").css("display", "block");
          $(".sec5").css("display", "none");
        });
      });    
      
      $(document).ready(function(){
        $(".s-button__remove3").click(function(){
          $(".sec3").css("display", "none");
          $(".sec4").css("display", "none");
          $(".sec5").css("display", "block");
        });
      });